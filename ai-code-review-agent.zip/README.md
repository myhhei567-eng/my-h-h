
# 🤖 Multi-Agent Code Review System

## 🚀 功能
- 自动代码审查（Reviewer Agent）
- 自动修复代码（Fixer Agent）
- 自动生成测试建议（Tester Agent）
- 多 Agent 协作流程

## 📦 安装
```bash
pip install -r requirements.txt
```

## 🔑 配置
复制 `.env.example` 为 `.env` 并填写 API Key：
```bash
cp .env.example .env
```

## ▶️ 运行
```bash
python main.py
```

## 🧠 架构
Reviewer → Fixer → Tester

## ✨ 示例
输入错误代码：
```python
def add(a,b)
    return a+b
```
系统会自动修复并给出测试建议

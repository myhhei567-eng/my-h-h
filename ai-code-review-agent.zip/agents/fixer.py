
    from utils.llm import call_llm

    def fix_code(code, review):
        prompt = f"""
根据以下 Review 修复代码：

Review:
{review}

原始代码：
{code}

要求：
- 修复所有问题
- 返回完整代码
- 添加注释
"""
        return call_llm(prompt)

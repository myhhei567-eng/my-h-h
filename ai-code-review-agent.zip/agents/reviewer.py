
    from utils.llm import call_llm

    def review_code(code):
        prompt = f"""
请对以下代码进行 Code Review：
- Bug
- 性能问题
- 安全问题
- 可读性问题

代码：
{code}

输出：
1. 问题列表
2. 严重程度
3. 修改建议
"""
        return call_llm(prompt)

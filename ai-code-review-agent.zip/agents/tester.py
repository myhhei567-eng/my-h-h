
    from utils.llm import call_llm

    def test_code(code):
        prompt = f"""
为以下代码生成测试用例：

代码：
{code}

输出：
1. 测试用例
2. 潜在问题
"""
        return call_llm(prompt)

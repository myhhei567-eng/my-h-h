
    from agents.reviewer import review_code
    from agents.fixer import fix_code
    from agents.tester import test_code

    def run_pipeline(code):
        print("🔍 Step 1: Code Review...")
        review = review_code(code)
        print(review)

        print("\n🛠 Step 2: Fix Code...")
        fixed_code = fix_code(code, review)
        print(fixed_code)

        print("\n🧪 Step 3: Test Code...")
        test_result = test_code(fixed_code)
        print(test_result)

    if __name__ == "__main__":
        sample_code = """
def add(a,b)
    return a+b

print(add(1,2))
"""
        run_pipeline(sample_code)
